function Loader() {
  return (
    <div className="fixed inset-0 z-10 flex items-center justify-center bg-stone-100">
      <div className="loader"></div>
    </div>
  );
}

export default Loader;
